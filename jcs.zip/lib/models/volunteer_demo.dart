class VolunteerDemo{
  String ? name;
  String ? imgPath;
  String ? lName;
  String ? userName;
  String ? age;
  String ? skill;

  VolunteerDemo({this.name,this.imgPath,this.lName,this.userName,this.age,this.skill});
}