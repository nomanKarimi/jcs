class NotificationData{
  String ? message;
  NotificationData({this.message});
}