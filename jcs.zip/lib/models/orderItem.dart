class EventDemo{
  String ?imgPath;
  String ?title;
  String ?exDate;
  String ?time;
  String ?pickLocation;
  bool ?isAccepted;
  EventDemo({this.imgPath,this.title,this.exDate,this.pickLocation,this.isAccepted,this.time});
}
